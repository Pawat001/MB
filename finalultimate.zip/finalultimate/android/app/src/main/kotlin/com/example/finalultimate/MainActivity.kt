package com.example.finalultimate

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
