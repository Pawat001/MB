import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final String apiUrl = "https://jsonplaceholder.typicode.com/posts"; // ตัวอย่าง API
  List<dynamic> _data = [];
  TextEditingController _controller = TextEditingController();

  // ✅ ดึงข้อมูลจาก API
  Future<void> fetchData() async {
    final response = await http.get(Uri.parse(apiUrl));
    if (response.statusCode == 200) {
      setState(() {
        _data = json.decode(response.body);
      });
    }
  }

  // ✅ เพิ่มข้อมูลใหม่
  Future<void> createData(String title) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      body: json.encode({"title": title, "body": "Example body"}),
      headers: {"Content-Type": "application/json"},
    );
    if (response.statusCode == 201) {
      fetchData();
    }
  }

  // ✅ อัปเดตข้อมูล
  Future<void> updateData(int id, String newTitle) async {
    final response = await http.put(
      Uri.parse("$apiUrl/$id"),
      body: json.encode({"title": newTitle, "body": "Updated body"}),
      headers: {"Content-Type": "application/json"},
    );
    if (response.statusCode == 200) {
      fetchData();
    }
  }

  // ✅ ลบข้อมูล
  Future<void> deleteData(int id) async {
    final response = await http.delete(Uri.parse("$apiUrl/$id"));
    if (response.statusCode == 200) {
      fetchData();
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(labelText: "Enter title"),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () {
                    createData(_controller.text);
                    _controller.clear();
                  },
                )
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _data.length,
              itemBuilder: (context, index) {
                final item = _data[index];
                return ListTile(
                  title: Text(item['title']),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () {
                          updateData(item['id'], "Updated Title ${item['id']}");
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          deleteData(item['id']);
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
